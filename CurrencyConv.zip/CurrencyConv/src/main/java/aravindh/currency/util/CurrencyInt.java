package aravindh.currency.util;

public interface CurrencyInt {
	double calculate(double amount);
}
